from django.contrib import admin
from .models import Question,User,Choice
# Register your models here.
class UserInline(admin.TabularInline):
    model = User
    extra = 3
class ChoiceInline(admin.TabularInline):
    model = Choice
    extra = 3
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('question_text','pub_date','was_published_recently')
    list_filter = ['pub_date']
    list_per_page = 5#控制在每个分页的管理员更改列表页面上显示多少个项目
    search_fields = ('question_text',)
    inlines = [UserInline,ChoiceInline]
    fieldsets = (
        ['Main',{
            'fields':('question_text',),
        }],
        ['Advance',{
            'classes': ('collapse',),
            'fields': ('pub_date',),
        }]
 
    )


admin.site.register(Question,QuestionAdmin)
